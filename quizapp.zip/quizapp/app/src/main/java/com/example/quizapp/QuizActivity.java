package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity {

    private String quizType;
    private final String[] mathQuestions = {
            "Q1:What is 2+2?", "Q2:What is 5*3?", "Q3:What is 7-4?", "Q4:What is 10/2?"
    };
    private final String[] physicsQuestions = {
            "Q1:What is the force formula?", "Q2:What is the unit of mass?",
            "Q3:What is the acceleration due to gravity?", "Q4:What is Newton's first law?"
    };

    private final String[][] mathOptions = {
            {"3", "4", "5", "6"},
            {"15", "20", "25", "30"},
            {"3", "2", "5", "1"},
            {"2", "4", "6", "5"}
    };

    private final String[][] physicsOptions = {
            {"F = ma", "F = mv", "F = m/g", "F = m*v"},
            {"Kg", "Lb", "Oz", "Gm"},
            {"9.8 m/s²", "10 m/s²", "5 m/s²", "9.81 m/s²"},
            {"An object at rest stays at rest", "Energy cannot be created",
                    "For every action, there is an equal and opposite reaction",
                    "Force equals mass times velocity"}
    };

    private final int[] mathAnswers = {1, 0, 0, 3};
    private final int[] physicsAnswers = {0, 0, 0, 0};

    private int currentQuestion = 0;
    private int score = 0;
    private final StringBuilder incorrectQuestionsFeedback = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        quizType = getIntent().getStringExtra("quizType");

        TextView tvQuestion = findViewById(R.id.tv_question);
        RadioGroup rgOptions = findViewById(R.id.rg_options);
        RadioButton rbOption1 = findViewById(R.id.rb_option1);
        RadioButton rbOption2 = findViewById(R.id.rb_option2);
        RadioButton rbOption3 = findViewById(R.id.rb_option3);
        RadioButton rbOption4 = findViewById(R.id.rb_option4);
        Button btnNext = findViewById(R.id.btn_next);

        loadQuestion(tvQuestion, rbOption1, rbOption2, rbOption3, rbOption4, rgOptions);

        btnNext.setOnClickListener(v -> {
            int selectedId = rgOptions.getCheckedRadioButtonId();
            if (selectedId == -1) {
                return; // No option selected
            }

            RadioButton selectedOption = findViewById(selectedId);
            int selectedIndex = rgOptions.indexOfChild(selectedOption);

            if (quizType.equals("Math")) {
                if (selectedIndex == mathAnswers[currentQuestion]) {
                    score++;
                } else {
                    incorrectQuestionsFeedback.append("Question: '")
                            .append(mathQuestions[currentQuestion])
                            .append("' - Correct answer: ")
                            .append(mathOptions[currentQuestion][mathAnswers[currentQuestion]])
                            .append("\n");
                }
            } else if (quizType.equals("Physics")) {
                if (selectedIndex == physicsAnswers[currentQuestion]) {
                    score++;
                } else {
                    incorrectQuestionsFeedback.append("Question: '")
                            .append(physicsQuestions[currentQuestion])
                            .append("' - Correct answer: ")
                            .append(physicsOptions[currentQuestion][physicsAnswers[currentQuestion]])
                            .append("\n");
                }
            }

            currentQuestion++;
            String feedback;
            if (currentQuestion < 4) { // Limit to 4 questions
                loadQuestion(tvQuestion, rbOption1, rbOption2, rbOption3, rbOption4, rgOptions);
            } else {

                if (score == 0) {
                    feedback = "Better luck next time! Try harder.";
                } else if (score == 3) {
                    feedback = "Good job! Almost perfect!";
                } else if (score == 4) {
                    feedback = "Excellent! You got full marks!";
                } else {
                    feedback = "Keep practicing!";
                }

                Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
                intent.putExtra("score", score);
                intent.putExtra("feedback", feedback);
                intent.putExtra("incorrectQuestionsFeedback", incorrectQuestionsFeedback.toString().isEmpty() ? "No incorrect answers." : incorrectQuestionsFeedback.toString());
                startActivity(intent);
            }
        });
    }

    private void loadQuestion(TextView tvQuestion, RadioButton rbOption1, RadioButton rbOption2,
                              RadioButton rbOption3, RadioButton rbOption4, RadioGroup rgOptions) {
        rgOptions.clearCheck(); // Clear previous selection

        if (quizType.equals("Math")) {
            tvQuestion.setText(mathQuestions[currentQuestion]);
            rbOption1.setText(mathOptions[currentQuestion][0]);
            rbOption2.setText(mathOptions[currentQuestion][1]);
            rbOption3.setText(mathOptions[currentQuestion][2]);
            rbOption4.setText(mathOptions[currentQuestion][3]);
        } else {
            tvQuestion.setText(physicsQuestions[currentQuestion]);
            rbOption1.setText(physicsOptions[currentQuestion][0]);
            rbOption2.setText(physicsOptions[currentQuestion][1]);
            rbOption3.setText(physicsOptions[currentQuestion][2]);
            rbOption4.setText(physicsOptions[currentQuestion][3]);
        }
    }
}
