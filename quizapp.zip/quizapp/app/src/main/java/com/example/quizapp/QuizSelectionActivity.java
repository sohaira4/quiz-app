package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class QuizSelectionActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_selection);

        Button btnMath = findViewById(R.id.btn_math);
        Button btnPhysics = findViewById(R.id.btn_physics);

        btnMath.setOnClickListener(v -> {
            Intent intent = new Intent(QuizSelectionActivity.this, QuizActivity.class);
            intent.putExtra("quizType", "Math");
            startActivity(intent);
        });

        btnPhysics.setOnClickListener(v -> {
            Intent intent = new Intent(QuizSelectionActivity.this, QuizActivity.class);
            intent.putExtra("quizType", "Physics");
            startActivity(intent);
        });
    }
}
