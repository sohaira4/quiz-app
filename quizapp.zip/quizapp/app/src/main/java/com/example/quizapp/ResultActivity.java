package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;

import android.text.SpannableString;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView tvResult = findViewById(R.id.tv_result);
        Button btnRestart = findViewById(R.id.btn_restart);

        int score = getIntent().getIntExtra("score", 0);
        String feedback = getIntent().getStringExtra("feedback");
        String incorrectFeedback = getIntent().getStringExtra("incorrectQuestionsFeedback");
        SpannableString spannable = new SpannableString("Your Score: " + score + "\n"+ feedback+"\n"+ incorrectFeedback);
        tvResult.setText(spannable);





        btnRestart.setOnClickListener(v -> {
            Intent intent = new Intent(ResultActivity.this, QuizSelectionActivity.class);
            startActivity(intent);
        });
    }
}

